## 1.1.2
Updated flutter_secure_storage_platform_interface to latest version.

## 1.1.1
Fixed an issue where no error was being reported if there was something wrong accessing the secret service.

## 1.1.0
Add containsKey function.

## 1.0.0
- Initial Linux implementation
- Removed unused Flutter test and effective_dart dependency