// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'operator.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_Operator _$$_OperatorFromJson(Map<String, dynamic> json) => _$_Operator(
      name: json['NAME'] as String?,
    );

Map<String, dynamic> _$$_OperatorToJson(_$_Operator instance) =>
    <String, dynamic>{
      'NAME': instance.name,
    };
